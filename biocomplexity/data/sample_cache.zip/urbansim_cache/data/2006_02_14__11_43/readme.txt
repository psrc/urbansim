This urbansim cache contains only the gridcells table - 
and the table only contains the attributes that is
needed by the land cover change model.