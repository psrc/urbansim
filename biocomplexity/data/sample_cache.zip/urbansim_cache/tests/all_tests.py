# Opus/UrbanSim urban simulation software.
# Copyright (C) 2005-2009 University of Washington
# See opus_core/LICENSE 

from opus_core.tests.utils.package_tester import PackageTester

PackageTester().run_all_tests_for_package('urbansim_cache')